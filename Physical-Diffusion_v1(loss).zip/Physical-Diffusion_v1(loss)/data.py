import os
import numpy as np
from scipy.interpolate import RegularGridInterpolator
import scipy.io as sio
import numpy as np
import matplotlib.pyplot as plt
from scipy.stats import gaussian_kde
from torch.utils.data import DataLoader,Dataset,random_split


class Loader(Dataset):
    def __init__(self, datasize=25, N_points=100) -> None:
        """
        data["X"]: (2,1000,400)
        data["Up"]: (2,1000,400)
        data["Ub"]:  (2,1000,400)
        """
        super().__init__()
        self.X=[]
        self.Up=[]
        self.Ub=[]
        self.tX=[]
        self.tUp=[]
        self.tUb=[]
        index=np.random.choice(np.arange(100),datasize,replace=False)+1
        source=np.random.choice(np.arange(20),datasize,replace=True)+1
        test=[i+1 for i in range(100) if i+1 not in index]
        tsource=[i+1 for i in range(20) if i+1 not in source]
        for i in range(len(index)):
            data=sio.loadmat(f"/home/junhao/CVPR25/Velocity/dt0p01_T4_kappa0p2_1000_samples_FHIT_velo_{index[i]}_source_{source[i]}.mat")
            self.Vel=sio.loadmat(f"/home/junhao/CVPR25/Velocity/recordinguv{index[i]}.mat")
            point=np.random.randint(1,1001,size=N_points)
            self.X.append(data["X"][:,point,:])
            self.Up.append(data["Up"][:,point,:])
            self.Ub.append(data["Ub"][:,point,:])
        for i in range(len(test)):
            data=sio.loadmat(f"/home/junhao/CVPR25/Velocity/dt0p01_T4_kappa0p2_1000_samples_FHIT_velo_{test[i]}_source_{tsource[i]}.mat")
            self.tVel=sio.loadmat(f"/home/junhao/CVPR25/Velocity/recordinguv{test[i]}.mat")
            point=np.random.randint(1,1001,size=N_points)
            self.tX.append(data["X"][:,point,:])
            self.tUp.append(data["Up"][:,point,:])
            self.tUb.append(data["Ub"][:,point,:])
        self.X=np.array(self.X)
        self.Up=np.array(self.Up)
        self.Ub=np.array(self.Ub)
        self.tX=np.array(self.tX)
        self.tUp=np.array(self.tUp)
        self.tUb=np.array(self.tUb)

    def __len__(self):
        return len(self.X)

    def __getitem__(self, index):
        return np.transpose(self.X[index],(2,1,0)),np.transpose(self.Up[index],(2,1,0)), np.transpose(self.Ub[index],(2,1,0)) # (time, points, x-y)




